Boxxle II - Protech Bug Eraser 0.2  [Radiant Nighte]




fixes:  [japan, usa / europe]
+ stop micro-stutter pauses, frame-skipping or briefly glitched music
+ stop flickering when closing menus
+ stop joypad from auto-sending too many button presses
+ always animate player when moving around
+ uses less battery power

= adjust small-mode sprites to match their large-mode counterparts





fixes:  [usa / europe]
+ stop flicker during title screen animation





source: MIT license
https://github.com/radimerry/boxxle2-gb/tree/game-fixes






changelog:

0.2  https://github.com/radimerry/boxxle2-gb/compare/game-fixes-0.1...game-fixes-0.2
= original 24 fps for small mode walking
= lower battery usage
