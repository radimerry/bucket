Snoopy Magic Show - Protech Bug Eraser 0.2  [Radiant Nighte]



Fixes:  [Japan, Usa, Japan dx 1.0 - marc_max]
+ Adds missing bottom star corners during ending
+ Adds missing bottom-right corner pixel of border window

# Move victory pose ypos during versus win when other player dies
# Move Snoopy and Spike starting position during title screen to avoid pop-in from right side

- Removes screen flicker during ending mid-scene
- Removes sprite garbage during ending mid-scene
- Removes 2 frames of micro-stutter during gameplay




Fixes:  [Japan dx 1.0 - marc_max]
+ Adds missing pixel of flag during ending
+ Adds missing pixel of sky during story cutscene
+ Adds missing star and text animation during ending

- Removes 1 frame of screen flicker during legal screen
- Removes tile garbage and 1 frame of screen flicker during 2P versus menu




Tested patching order:
- Japan + Protech
- USA + Protech

- Japan + DX 1.0 + Protech




Changelog:
- 0.2   https://github.com/radimerry/snoopy-magic-show-gb/compare/1678828e6622c8707826b3ffab6d8b3c206549fb..a5da6ae02b8bcb5c6102d325a72361bb8b376880




Source: MIT License
https://github.com/radimerry/snoopy-magic-show-gb/tree/fixes
