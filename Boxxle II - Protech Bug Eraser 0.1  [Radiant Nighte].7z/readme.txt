Boxxle II - Protech Bug Eraser 0.1  [Radiant Nighte]



fixes:  [japan, usa / europe]
+ stop micro-stutter pauses, frame-skipping or briefly glitched music
+ stop flickering when closing menus
+ stop joypad from auto-sending too many button presses
+ always animate player when moving around

= adjust small-mode sprites to match their large-mode counterparts




fixes:  [usa / europe]
+ stop flicker during title screen animation




source: MIT license
https://github.com/radimerry/boxxle2-gb/tree/game-fixes
