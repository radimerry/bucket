Boxxle II - Protech Hacks Catalog 0.1  [Radiant Nighte]




Shuffle Music 0.1:  [japan, usa / europe]
- Changes music track after every stage clear or retry




Tested patching order:
- Japan + Protech
- USA + Protech




Source: MIT License
https://github.com/radimerry/boxxle2-gb/tree/hacks-catalog
