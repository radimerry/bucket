Boxxle II - Protech Hacks Catalog 0.2  [Radiant Nighte]




shuffle music 0.1:  [japan, usa / europe]
- changes music track after every stage clear or retry





faster walk 0.2: [japan, usa / europe]
- changes movement speed from 24 fps to 30 / 40 in small mode






tested patching order:
- japan / usa - europe
  protech bug fixes  [OPTIONAL]
  protech hacks catalog






source: MIT license
https://github.com/radimerry/boxxle2-gb/tree/hacks-catalog






changelog:

0.2  https://github.com/radimerry/boxxle2-gb/compare/hacks-catalog-0.1...hacks-catalog-0.2
= faster walk patch
