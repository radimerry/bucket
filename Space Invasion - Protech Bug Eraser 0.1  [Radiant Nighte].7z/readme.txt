Space Invasion - Protech Bug Eraser 0.1  [Radiant Nighte]




Fixes:  [Europe, Multi2 - Karate Joe, Multi2 - Painter]
# Draw correct enemy sprite bullets  (later GBC revisions, GBA)





Tested patching order:
- Europe + Protech





Source: MIT License
https://github.com/radimerry/space-invasion-gbc/tree/game-fixes
